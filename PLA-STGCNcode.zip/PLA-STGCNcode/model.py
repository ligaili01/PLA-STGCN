import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_add_pool
import numpy as np
import math
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class GNN_LBA(torch.nn.Module):
    def __init__(self, num_features, hidden_dim, num_layers=2, look_back=40,
                 pre_len=1):
        super(GNN_LBA, self).__init__()
        self.conv1 = GCNConv(num_features, hidden_dim)
        self.bn1 = nn.BatchNorm1d(hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim*2)
        self.bn2 = nn.BatchNorm1d(hidden_dim*2)
        self.conv3 = GCNConv(hidden_dim*2, hidden_dim*4)
        self.bn3 = nn.BatchNorm1d(hidden_dim*4)
        #self.conv4 = GCNConv(hidden_dim*4, hidden_dim*4)
        #self.bn4 = nn.BatchNorm1d(hidden_dim*4)
        #self.conv5 = GCNConv(hidden_dim*4, hidden_dim*8)
        #self.bn5 = nn.BatchNorm1d(hidden_dim*8)
        self.net = STGCN(num_nodes=hidden_dim*4, num_features=hidden_dim*4, num_timesteps_input=11,
                num_timesteps_output=64).to(device)
        self.biGRU= BiRNN(input_size=hidden_dim, hidden_size=16,
                            num_layers=2, num_classes=100).to(device)
        self.look_back=look_back
        self.pre_len=pre_len
        self.Softmax=nn.Softmax(dim=1)
        self.fc1 = nn.Linear(64, 16)
        self.fc2 = nn.Linear(16, 1)
    def Atten(self,H):
        look_back=20,
        h=H[:,-1,:].unsqueeze(1) #[batch_size,1,128]
       # print(h.shape)
        H=H[:,-1-self.look_back:-1,:] #[batch_size,look_back,128]
       # print(H.shape)
        atten=torch.matmul(h,H.transpose(1,2)).transpose(1,2) #注意力矩阵
        #print(atten.shape)
        atten=self.Softmax(atten)
        atten_H=atten*H #带有注意力的历史隐状态
        #print(atten_H.shape)
        atten_H=torch.sum(atten_H,dim=1).unsqueeze(1) #按时间维度降维
        return torch.cat((atten_H,h),2).squeeze(1)   


    def forward(self, x, edge_index, edge_weight, batch):
        x = self.conv1(x, edge_index, edge_weight)
        x = F.relu(x)
        x = self.bn1(x)
        x = self.conv2(x, edge_index, edge_weight)
        x = F.relu(x)
        x = self.bn2(x)
        x = self.conv3(x, edge_index, edge_weight)
        x = F.relu(x)
        x = self.bn3(x)
        #x = self.conv4(x, edge_index, edge_weight)
        #x = self.bn4(x)
        #x = F.relu(x)
        #x = self.conv5(x, edge_index, edge_weight)
        #x = self.bn5(x)
        x = global_add_pool(x, batch)
        x =x.unsqueeze(-1)
        x =x.unsqueeze(-1)
        x = self.net(x)
        #x = self.biGRU(x)
        x = x.view(len(x), 1, -1)
        #h_atten=self.Atten(x)
        #x = F.relu(x)
        x = F.relu(self.fc1(x))
        #x = F.dropout(x, p=0.25, training=self.training)
        return self.fc2(x).view(-1)

class BiRNN(nn.Module):
   
    def __init__(self, input_size, hidden_size,
                 num_layers, num_classes=10):
        super(BiRNN, self).__init__()
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers=3
        self.lstm = nn.LSTM(input_size, hidden_size,
                            num_layers, batch_first=True,
                            bidirectional=True)
        self.fc = nn.Linear(hidden_size*2, num_classes)  # 2 for bidirection
    
    def forward(self, x):
        # Set initial states
        x = x.view(len(x), 1, -1)
        h0 = torch.zeros(self.num_layers*2, x.size(0),
                         self.hidden_size).to(device)  # 2 for bidirection
        c0 = torch.zeros(self.num_layers*2, x.size(0),
                         self.hidden_size).to(device)
        
        # Forward propagate LSTM
        out, _ = self.lstm(x, (h0, c0))  # out: tensor of shape (batch_size, seq_length, hidden_size*2)
        
        # Decode the hidden state of the last time step
        out = self.fc(out[:, -1, :])
        return out


class TimeBlock(nn.Module):
    """
    Neural network block that applies a temporal convolution to each node of
    a graph in isolation.
    """

    def __init__(self, in_channels, out_channels, kernel_size=1):
        """
        :param in_channels: Number of input features at each node in each time
        step.
        :param out_channels: Desired number of output channels at each node in
        each time step.
        :param kernel_size: Size of the 1D temporal kernel.
        """
        super(TimeBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv2 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv3 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))

    def forward(self, X):
        """
        :param X: Input data of shape (batch_size, num_nodes, num_timesteps,
        num_features=in_channels)
        :return: Output data of shape (batch_size, num_nodes,
        num_timesteps_out, num_features_out=out_channels)
        """
        # Convert into NCHW format for pytorch to perform convolutions.
        #X = X.permute(0, 3, 1, 2)
        #X = X.permute(0, 2, 1, 3)
        #X = X.permute(2, 0, 1, 3)
        temp = self.conv1(X) + torch.sigmoid(self.conv2(X))
        out = F.relu(temp + self.conv3(X))
        # Convert back from NCHW to NHWC
        out = out.permute(0, 2, 3, 1)
        return out


class STGCNBlock(nn.Module):
    """
    Neural network block that applies a temporal convolution on each node in
    isolation, followed by a graph convolution, followed by another temporal
    convolution on each node.
    """

    def __init__(self, in_channels, spatial_channels, out_channels,
                 num_nodes):
        """
        :param in_channels: Number of input features at each node in each time
        step.
        :param spatial_channels: Number of output channels of the graph
        convolutional, spatial sub-block.
        :param out_channels: Desired number of output features at each node in
        each time step.
        :param num_nodes: Number of nodes in the graph.
        """
        super(STGCNBlock, self).__init__()
        self.temporal1 = TimeBlock(in_channels=in_channels,
                                   out_channels=out_channels)
        self.Theta1 = nn.Parameter(torch.FloatTensor(out_channels,
                                                     spatial_channels))
        self.temporal2 = TimeBlock(in_channels=spatial_channels,
                                   out_channels=out_channels)
        self.batch_norm = nn.BatchNorm2d(1)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.Theta1.shape[1])
        self.Theta1.data.uniform_(-stdv, stdv)

    def forward(self, X):
        """
        :param X: Input data of shape (batch_size, num_nodes, num_timesteps,
        num_features=in_channels).
        :param A_hat: Normalized adjacency matrix.
        :return: Output data of shape (batch_size, num_nodes,
        num_timesteps_out, num_features=out_channels).
        """
        #X=X.unsqueeze(-1)
        #X=X.unsqueeze(-1)
        #X =X.squeeze(-1)
        #X =X.squeeze(-1)
        #print(X)
        t = self.temporal1(X)
        #t = t.permute(2, 3, 0, 1)
        #t=t.unsqueeze(-1)
        #t=t.unsqueeze(-1)
        #print(t)
        #t1 = torch.Tensor(16, 64)
        #t1=nn.Linear(16, 64)
        #lfs=self.Theta1.repeat(t)
        #lfs = torch.einsum("ij,jklm->kilm", [t, t.permute(1, 0, 2, 3)])
        #t2 = F.relu(torch.einsum("ijkl,lp->ijkp", [lfs, self.Theta1]))
        #t2 = F.relu(torch.matmul(t1, self.Theta1))
        #t2 =t2.unsqueeze(-1)
        #t2 =t2.unsqueeze(-1)
        t2 = F.relu(t)
        #t2 = t2.permute(0, 3, 2, 1)
        t2 = t2.permute(3, 0, 2, 1)
        t2 = t2.permute(1, 0, 2, 3)
        t3 = self.temporal2(t2)
        return self.batch_norm(t3)
        # return t3


class STGCN(nn.Module):
    """
    Spatio-temporal graph convolutional network as described in
    https://arxiv.org/abs/1709.04875v3 by Yu et al.
    Input should have shape (batch_size, num_nodes, num_input_time_steps,
    num_features).
    """

    def __init__(self, num_nodes, num_features, num_timesteps_input,
                 num_timesteps_output):
        """
        :param num_nodes: Number of nodes in the graph.
        :param num_features: Number of features at each node in each time step.
        :param num_timesteps_input: Number of past time steps fed into the
        network.
        :param num_timesteps_output: Desired number of future time steps
        output by the network.
        """
        super(STGCN, self).__init__()
        self.block1 = STGCNBlock(in_channels=num_features, out_channels=64,
                                 spatial_channels=64, num_nodes=256)
        self.block2 = STGCNBlock(in_channels=64, out_channels=64,
                                 spatial_channels=64, num_nodes=256)
        self.last_temporal = TimeBlock(in_channels=64, out_channels=64)
        self.fully = nn.Linear((num_timesteps_input - 2 * 5) * 64,
                               num_timesteps_output)

    def forward(self, X):
        """
        :param X: Input data of shape (batch_size, num_nodes, num_timesteps,
        num_features=in_channels).
        :param A_hat: Normalized adjacency matrix.
        """
        out1 = self.block1(X)
        out1 = out1.permute(0, 3, 1, 2)
        #out1 = out1.permute(1, 0, 1, 2)
        out2 = self.block2(out1)
        out2 = out2.permute(0, 3, 1, 2)
        out3 = self.last_temporal(out2)
        #out3 = out3.permute(1, 0, 2, 3)
        out4 = self.fully(out3.reshape((out3.shape[0], out3.shape[1], -1)))
        return out4



